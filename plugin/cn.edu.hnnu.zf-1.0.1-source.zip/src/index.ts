import type {
  AcademicPlugin, Context, HostSdk, HtmlNode, Result, Schedule, ScheduleEntry, Term, Terms
} from '../../../sdk/index';

/**
 * 淮南师范学院 · 正方教务（jwglxt V9）学期与课表读取。
 *
 * 与内置正方适配的差别只有两处，其余全部继承：
 * - 课表功能号是「个人课表查询」N2151，不是正方默认的 N253508；
 * - 学期下拉只出现在课表首页 /kbcx/xskbcx_cxXskbcxIndex.html 上，
 *   课表数据仍由 /kbcx/xskbcx_cxXsKb.html 返回。
 *
 * 样本为结构样本，尚未经过学校账号验收。
 */

const SCHEDULE_GNMKDM = 'N2151';
const TERMS_PATH = '/kbcx/xskbcx_cxXskbcxIndex.html';
const SCHEDULE_PATH = '/kbcx/xskbcx_cxXsKb.html';
/** SDK 上限：课表最多 25 周。 */
const MAX_WEEKS = 25;
/** 学期没有返回任何周次时的兜底周数，避免只渲染出两周。 */
const FALLBACK_WEEKS = 20;

const TERM_PATTERN = /(\d{4})\D+(\d{4})\D+([123])(?:\D|$)/;
const YEAR_FIELDS = ['xnm', 'xnd', 'ddlXN', 'xn'];
const SEMESTER_FIELDS = ['xqm', 'xqd', 'ddlXQ', 'xq'];

function api(context: Context, path: string): string {
  return context.baseUrl.replace(/\/+$/, '') + path;
}

function attr(node: HtmlNode, name: string): string {
  const value = node.attributes[name];
  return typeof value === 'string' ? value : '';
}

/**
 * 布尔属性（selected / disabled）在没有值时解析成空串，
 * 只看值会把「写了属性」和「没写属性」混为一谈。
 */
function hasAttr(node: HtmlNode, name: string): boolean {
  const value = node.attributes[name];
  if (typeof value !== 'string') return false;
  return value !== '' || Object.prototype.hasOwnProperty.call(node.attributes, name);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/** 取第一个有值的文本字段；JSON 里的 null 一律按空处理。 */
function field(row: Record<string, unknown>, keys: string[]): string {
  for (const key of keys) {
    const value = row[key];
    if (typeof value === 'string') {
      const text = value.trim();
      if (text !== '') return text;
    } else if (typeof value === 'number' && Number.isFinite(value)) {
      return String(value);
    }
  }
  return '';
}

function intField(row: Record<string, unknown>, keys: string[]): number | null {
  for (const key of keys) {
    const value = row[key];
    const number = typeof value === 'number' ? value
      : typeof value === 'string' && value.trim() !== '' ? Number(value.trim())
        : Number.NaN;
    if (Number.isFinite(number)) return Math.trunc(number);
  }
  return null;
}

function arrayField(root: unknown, keys: string[]): Record<string, unknown>[] {
  if (Array.isArray(root)) return root.filter(isRecord);
  if (!isRecord(root)) return [];
  for (const key of keys) {
    const value = root[key];
    if (Array.isArray(value)) return value.filter(isRecord);
  }
  if (isRecord(root['data'])) return arrayField(root['data'], keys);
  return [];
}

function rowsOf(body: string, keys: string[]): Record<string, unknown>[] {
  const text = body.trim();
  if (text === '' || (text.charAt(0) !== '{' && text.charAt(0) !== '[')) return [];
  let root: unknown;
  try {
    root = JSON.parse(text) as unknown;
  } catch {
    return [];
  }
  return arrayField(root, keys);
}

/** 正方把失效会话直接换成登录页，必须先看出来，否则会把登录页当成空课表。 */
function isLoginPage(body: string): boolean {
  if (/<input[^>]*(?:type\s*=\s*["']?password|name\s*=\s*["']?(?:mm|TextBox2))/i.test(body)) return true;
  if (/location(?:\.href)?\s*=\s*['"][^'"]*(?:login_slogin|default2\.aspx|LoginToXk)/i.test(body)) return true;
  return /请先登录|登录超时|会话失效|notLogin/.test(body);
}

function parseTermId(value: string): string | null {
  const match = TERM_PATTERN.exec(value);
  if (!match) return null;
  const year = Number(match[1]);
  return `${year}-${year + 1}-${match[3]}`;
}

function toTerm(id: string): Term {
  const parts = id.split('-');
  const year = Number(parts[0]);
  const semester = Number(parts[2]);
  return {
    id,
    name: `${year}-${year + 1}学年第${semester}学期`,
    year,
    semester,
    order: year * 10 + semester
  };
}

function xqmToSemester(value: string): number {
  if (value === '3' || value === '1') return 1;
  if (value === '12' || value === '2') return 2;
  if (value === '16') return 3;
  const number = Number(value);
  return Number.isFinite(number) && number >= 1 && number <= 3 ? number : 0;
}

/**
 * 淮南把学期拆成「学年 select + 学期 select」两个下拉（xnm / xqm），
 * 组合出来的学期里**只有被 selected 标记的那一个才是当前学期**。
 * 少了这一步就会拿列表里最大的学期（例如 2028-2029-3）去查课表，
 * 学校会老实返回 200 + 空 kbList，界面表现为「课表加载成功但什么都没有」。
 */
function termsFromSelects(body: string, sdk: HostSdk): { terms: Term[]; currentId: string } {
  const years: number[] = [];
  const semesters: number[] = [];
  let selectedYear = 0;
  let selectedSemester = 0;
  for (const select of sdk.html.select(body, 'select[name]')) {
    const name = attr(select, 'name').split('$').pop() ?? '';
    for (const option of sdk.html.select(select.html, 'option')) {
      if (hasAttr(option, 'disabled')) continue;
      const value = attr(option, 'value').trim();
      const marked = hasAttr(option, 'selected');
      if (YEAR_FIELDS.indexOf(name) >= 0) {
        const year = Number(value.slice(0, 4));
        if (year >= 1900 && year <= 2300) {
          if (years.indexOf(year) < 0) years.push(year);
          if (marked && selectedYear === 0) selectedYear = year;
        }
      } else if (SEMESTER_FIELDS.indexOf(name) >= 0) {
        const semester = name === 'xqm' ? xqmToSemester(value) : Number(value);
        if (semester >= 1 && semester <= 3) {
          if (semesters.indexOf(semester) < 0) semesters.push(semester);
          if (marked && selectedSemester === 0) selectedSemester = semester;
        }
      }
    }
  }
  const terms: Term[] = [];
  for (const year of years) for (const semester of semesters) terms.push(toTerm(`${year}-${year + 1}-${semester}`));
  const currentId = selectedYear > 0 && selectedSemester > 0
    ? `${selectedYear}-${selectedYear + 1}-${selectedSemester}` : '';
  return { terms, currentId };
}

/** 页面没标 selected 时，按当前日期猜一个学期（9 月起算新学年第一学期）。 */
function calendarTermId(): string {
  try {
    const now = new Date();
    const month = now.getMonth() + 1;
    const year = month >= 9 ? now.getFullYear() : now.getFullYear() - 1;
    const semester = month >= 9 || month <= 2 ? 1 : 2;
    return `${year}-${year + 1}-${semester}`;
  } catch {
    return '';
  }
}

async function readTerms(_args: Record<string, never>, context: Context, sdk: HostSdk): Promise<Result<Terms>> {
  const response = await sdk.http({
    url: `${api(context, TERMS_PATH)}?gnmkdm=${SCHEDULE_GNMKDM}`,
    method: 'GET',
    purpose: 'query',
    charset: 'UTF-8'
  });
  if (isLoginPage(response.body)) {
    return { ok: false, error: { code: 'SESSION_EXPIRED', message: '登录已失效，请重新登录后再查询' } };
  }
  if (response.status < 200 || response.status > 299) {
    return { ok: false, error: { code: 'PAGE_CHANGED', message: '学校课表页面暂不可用，请稍后重试' } };
  }

  const terms: Term[] = [];
  let selectedId = '';
  for (const option of sdk.html.select(response.body, 'select option')) {
    if (hasAttr(option, 'disabled')) continue;
    const id = parseTermId(attr(option, 'value')) ?? parseTermId(option.text);
    if (!id) continue;
    if (!terms.some(term => term.id === id)) terms.push(toTerm(id));
    if (selectedId === '' && hasAttr(option, 'selected')) selectedId = id;
  }
  if (terms.length === 0) {
    const fallback = termsFromSelects(response.body, sdk);
    for (const term of fallback.terms) {
      if (!terms.some(item => item.id === term.id)) terms.push(term);
    }
    if (selectedId === '') selectedId = fallback.currentId;
  }
  if (terms.length === 0) {
    return { ok: false, error: { code: 'PAGE_CHANGED', message: '学校课表页面没有返回可识别的学期' } };
  }

  terms.sort((left, right) => (right.order ?? 0) - (left.order ?? 0));
  let currentId = selectedId;
  if (!terms.some(term => term.id === currentId)) currentId = calendarTermId();
  if (!terms.some(term => term.id === currentId)) currentId = terms[0].id;
  return { ok: true, data: { items: terms, currentId } };
}

/** "1-2" / "1,2" / "第1-2节" → [1, 2]。 */
function parsePeriods(value: string): [number, number] | null {
  if (value === '') return null;
  const clean = value.replace(/[第节\s]/g, '').replace(/[,~—–至]/g, '-');
  const parts = clean.split('-').filter(part => part !== '');
  if (parts.length === 0) return null;
  const first = Number(parts[0]);
  const last = Number(parts[parts.length - 1]);
  if (!Number.isFinite(first) || !Number.isFinite(last)) return null;
  const start = Math.min(first, last);
  const end = Math.max(first, last);
  if (start < 1 || end < start || end > 30) return null;
  return [start, end];
}

/** "1-16周" / "1-8,10-16周" / "1-16周(单)" → 周次数组。 */
function parseWeeks(value: string, maxWeeks: number): number[] {
  if (value.trim() === '') return [];
  const parts = value.replace(/\s+/g, '').split(/[,、;]+/);
  const weeks = new Set<number>();
  for (const part of parts) {
    if (part === '') return [];
    const odd = part.indexOf('单') >= 0;
    const even = part.indexOf('双') >= 0;
    if (odd && even) return [];
    const match = /^(\d{1,2})(?:[-~—–至](\d{1,2}))?$/.exec(part.replace(/[第周单双()（）]/g, ''));
    if (!match) return [];
    const first = Number(match[1]);
    const last = match[2] === undefined ? first : Number(match[2]);
    if (first < 1 || first > maxWeeks || last < first || last > maxWeeks) return [];
    for (let week = first; week <= last; week++) {
      if ((!odd || week % 2 === 1) && (!even || week % 2 === 0)) weeks.add(week);
    }
  }
  return Array.from(weeks).sort((left, right) => left - right);
}

/** 稳定 ID：只由学校返回的字段推导，不使用列表下标。 */
function entryId(seed: string): string {
  let forward = 0x811c9dc5;
  let backward = 0x01000193;
  for (let index = 0; index < seed.length; index++) {
    forward = ((forward ^ seed.charCodeAt(index)) * 0x01000193) >>> 0;
    backward = ((backward + seed.charCodeAt(index) * (index + 7)) ^ (forward >>> 3)) >>> 0;
  }
  return 'hnnu-kb-' + forward.toString(16).padStart(8, '0') + backward.toString(16).padStart(8, '0');
}

async function readSchedule(args: { termId: string }, context: Context, sdk: HostSdk): Promise<Result<Schedule>> {
  const parts = (args.termId ?? '').split('-');
  const year = Number(parts[0]);
  const semester = Number(parts[2]);
  if (!Number.isFinite(year) || year < 1900 || (semester !== 1 && semester !== 2 && semester !== 3)) {
    return { ok: false, error: { code: 'VALIDATION_FAILED', message: '学期参数无法识别，请重新选择学期' } };
  }
  const xqm = semester === 1 ? '3' : semester === 2 ? '12' : '16';

  const response = await sdk.http({
    url: `${api(context, SCHEDULE_PATH)}?gnmkdm=${SCHEDULE_GNMKDM}`,
    method: 'POST',
    purpose: 'query',
    charset: 'UTF-8',
    headers: { 'X-Requested-With': 'XMLHttpRequest' },
    form: { xnm: String(year), xqm }
  });
  if (isLoginPage(response.body)) {
    return { ok: false, error: { code: 'SESSION_EXPIRED', message: '登录已失效，请重新登录后再查询' } };
  }
  if (response.status < 200 || response.status > 299) {
    return { ok: false, error: { code: 'PAGE_CHANGED', message: '学校课表页面暂不可用，请稍后重试' } };
  }

  const entries: ScheduleEntry[] = [];
  let latestWeek = 0;
  for (const row of rowsOf(response.body, ['kbList', 'items'])) {
    const name = field(row, ['kcmc', 'KCMC']);
    if (name === '') continue;
    const day = intField(row, ['xqj', 'XQJ']);
    const periods = parsePeriods(field(row, ['jcs', 'JCS', 'jcor', 'JCOR']));
    if (day === null || day < 1 || day > 7 || periods === null) {
      return { ok: false, error: { code: 'PAGE_CHANGED', message: '课表缺少可识别的星期或节次' } };
    }
    const weeks = parseWeeks(field(row, ['zcd', 'ZCD', 'weeks']), MAX_WEEKS);
    const teacher = field(row, ['xm', 'XM', 'jsxm']);
    const location = [field(row, ['xqmc', 'cdxqmc']), field(row, ['cdmc', 'CDMC', 'jxcdmc'])]
      .filter(part => part !== '').join(' ');
    const sourceId = field(row, ['schedule_source_id', 'kcb_id', 'kb_id', 'jxb_id', 'jx0404id', 'kch_id']);
    const seed = sourceId !== ''
      ? [sourceId, day, periods[0], periods[1], weeks.join(',')].join('|')
      : [name, teacher, location, day, periods[0], periods[1], weeks.join(',')].join('|');
    const entry: ScheduleEntry = {
      id: entryId(seed),
      name,
      day,
      startPeriod: periods[0],
      endPeriod: periods[1],
      weeks
    };
    if (teacher !== '') entry.teacher = teacher;
    if (location !== '') entry.location = location;
    entries.push(entry);
    if (weeks.length > 0) latestWeek = Math.max(latestWeek, weeks[weeks.length - 1]);
  }

  const maxWeeks = Math.min(MAX_WEEKS, Math.max(FALLBACK_WEEKS, latestWeek));
  return { ok: true, data: { termId: args.termId, entries, maxWeeks } };
}

export default {
  study: {
    terms: readTerms,
    schedule: readSchedule
  }
} satisfies AcademicPlugin;
