# 淮南师范学院 · 正方教务适配 `cn.edu.hnnu.zf`

学校适配扩展，v1.0.1，API v1，`kind: extension` + `extends: builtin.zf`。
只替换**学期列表**与**课表**两个读取方法，登录和其它学习接口全部继承内置正方实现。

## 学校连接信息

| 项 | 值 |
| --- | --- |
| 域名 | `jwgl.hnnu.edu.cn` |
| 协议 | `https` |
| basePath | `/jwglxt` |
| 教务系统 | `zf`（正方 jwglxt V9） |
| 页面编码 | `UTF-8` |
| 允许的教务主机 | `jwgl.hnnu.edu.cn` |

## 为什么不是纯配置插件

淮南师范学院的课表入口不是正方默认的那个，光填学校地址不够：

- 课表功能号是「个人课表查询」**N2151**，不是正方默认的 `N253508`；
- 学期下拉只出现在课表首页 `/jwglxt/kbcx/xskbcx_cxXskbcxIndex.html` 上，
  课表数据仍由 `/jwglxt/kbcx/xskbcx_cxXsKb.html` 返回。

manifest 的 `school` 段没有承载功能号的字段，所以用 `extend-zf` 覆盖
`study.terms` 与 `study.schedule`，把这两处差异写进代码。

## 声明的网络范围

只声明了两条，路径精确到文件名，用途全部是 `query`（没有任何写入）：

- `GET https://jwgl.hnnu.edu.cn/jwglxt/kbcx/xskbcx_cxXskbcxIndex.html?gnmkdm=N2151`
- `POST https://jwgl.hnnu.edu.cn/jwglxt/kbcx/xskbcx_cxXsKb.html?gnmkdm=N2151`（表单 `xnm` / `xqm`）

## 解析规则

- 学期优先读 `select option` 的 `value` / 文本（`2026-2027-1`、`2026-2027学年第1学期` 两种写法都认）。
- 淮南实际是「学年 `xnm` + 学期 `xqm`」**两个独立下拉**（`xqm` 的 `3/12/16` 对应第 1/2/3 学期），
  组合出全部学期后，**当前学期必须按两个下拉各自的 `selected` 还原**（学年 `selected` + 学期 `selected`）。
  v1.0.0 忽略了 `selected`，直接取列表里最大的学期（如 `2028-2029-3`）去查课表：
  学校照样返回 `200` + 空 `kbList`，界面表现为「课表加载成功但一条都没有」，而且不报错——很难查。
  两个下拉都没标 `selected` 时，再退回到按当前日期推算的学期，最后才是列表最大值。
- 课表读 `kbList`（兼容 `items` / `data.kbList`），字段 `kcmc / xm / xqmc+cdmc / xqj / jcs / zcd`。
- 周次支持 `1-16周`、`1-8,10-16周`、`1-16周(单|双)`，上限 25 周。
- 条目 ID 由学校返回的 `jxb_id`（或课程名 + 教师 + 地点 + 星期 + 节次 + 周次）推导，不用列表下标。
- 会话失效时正方会直接返回登录页，插件识别后返回 `SESSION_EXPIRED`，不会把登录页当成空课表。

## 样本与验证状态

`fixtures/cases.json` 共 9 条样本（学期 4 条、课表 5 条），含成功、会话失效、
空课表、页面结构变化和参数校验失败：

```sh
npm run plugin -- check hnnu      # Checked cn.edu.hnnu.zf (2 capabilities)
npm run plugin -- test hnnu       # Passed 9 fixtures
npm run plugin -- pack hnnu       # dist/cn.edu.hnnu.zf-1.0.1.eduplugin
npm run plugin -- source-zip hnnu # dist/cn.edu.hnnu.zf-1.0.1-source.zip
```

v1.0.1 已用真实账号**只读**验收（登录 → 学期首页 → 课表查询，未提交任何请求）：

- 学期首页两个下拉：`xnm` 17 项（`selected=2026`）、`xqm` 4 项（`selected=3`）→ `currentId = 2026-2027-1`；
- `POST /jwglxt/kbcx/xskbcx_cxXsKb.html?gnmkdm=N2151`（`xnm=2026&xqm=3`）→ `kbList` 19 条，
  `kcmc / xm / xqmc+cdmc / xqj / jcs / zcd` 全部命中，`1-15周(单)`、`2-16周(双)` 解析正确；
- 用错误的未来学期查询（`2028-2029-3`）时学校返回 `200` + `kbList: []`，即 v1.0.0 那个空白课表的成因。

未覆盖：`allowedAcademicHosts` 之外的入口（备用入口 `211.70.176.172` 只有 http，
与这里声明的 `https` 冲突，因此没有写进本版）。

## 导入与提交

- 导入 App：设置 → 插件中心 → 打开开发者模式 → 导入适配包，选 `dist/cn.edu.hnnu.zf-1.0.1.eduplugin`。
- 提交审核：<https://plugins.hidisiwa.xyz/submit>，上传 `dist/cn.edu.hnnu.zf-1.0.1-source.zip`（10 KB 左右）。
- 提交前请确认源码里没有学号、姓名、Cookie 与真实成绩。
